import {User} from './user';
export const USERS:User[]=[
    {id:101,name:'Anu',email:'anu123@gmail.com',phone:213456},
    {id:102,name:'Abdus',email:'abdus23@gmail.com',phone:213589},
    {id:103,name:'Sadika',email:'sadika22@gmail.com',phone:453742},
    {id:104,name:'Anisha',email:'anisha7@gmail.com',phone:123367},
    {id:105,name:'Aarthi',email:'ar33@gmail.com',phone:927778}
]